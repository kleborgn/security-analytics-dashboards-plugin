## Maintainers
| Maintainer | GitHub ID | Affiliation |
| --------------- | --------- | ----------- |
| Ashish Agrawal | [lezzago](https://github.com/lezzago) | Amazon |
| Subhobrata Dey | [sbcd90](https://github.com/sbcd90) | Amazon |
| Praveen Sameneni | [praveensameneni](https://github.com/praveensameneni) | Amazon |
| Saurabh Singh | [getsaurabh02](https://github.com/getsaurabh02) | Amazon |

[This document](https://github.com/opensearch-project/.github/blob/main/MAINTAINERS.md) explains what maintainers do in this repo, and how they should be doing it. If you're interested in contributing, see [CONTRIBUTING](CONTRIBUTING.md).