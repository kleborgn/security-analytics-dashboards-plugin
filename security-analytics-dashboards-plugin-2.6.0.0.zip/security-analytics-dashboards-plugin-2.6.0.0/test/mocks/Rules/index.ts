/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import RuleOptions from './RuleOptions.mock';
import RulePage from './RulePage.mock';

export default {
  RuleOptions,
  RulePage,
};
