/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import { RulesPage } from '../../../types';

export default {
  index: 1,
} as RulesPage;
