/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

export { DarkModeConsumer, DarkModeContext } from "./DarkMode";
