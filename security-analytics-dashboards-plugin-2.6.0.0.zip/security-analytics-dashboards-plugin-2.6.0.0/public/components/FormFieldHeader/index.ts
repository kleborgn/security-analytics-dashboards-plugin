/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import { FormFieldHeader } from './FormFieldHeader';

export default FormFieldHeader;
