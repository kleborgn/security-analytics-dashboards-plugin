/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import { NotificationsCallOut } from './NotificationsCallOut';

export { NotificationsCallOut };
