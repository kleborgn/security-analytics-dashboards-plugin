/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import DeleteModal from './DeleteModal';

export default DeleteModal;
