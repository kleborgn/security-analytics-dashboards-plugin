/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import { Rules } from './containers/Rules/Rules';

export default Rules;
