/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import Detectors from './containers/Detectors';

export default Detectors;
