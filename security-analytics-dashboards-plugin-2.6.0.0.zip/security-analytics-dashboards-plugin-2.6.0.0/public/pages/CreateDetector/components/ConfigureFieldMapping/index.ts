/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import ConfigureFieldMapping from './containers/ConfigureFieldMapping';

export default ConfigureFieldMapping;
