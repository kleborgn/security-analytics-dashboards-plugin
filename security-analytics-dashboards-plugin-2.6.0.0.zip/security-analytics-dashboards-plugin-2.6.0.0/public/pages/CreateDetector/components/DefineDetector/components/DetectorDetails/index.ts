/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import DetectorBasicDetailsForm from './DetectorBasicDetailsForm';

export default DetectorBasicDetailsForm;
