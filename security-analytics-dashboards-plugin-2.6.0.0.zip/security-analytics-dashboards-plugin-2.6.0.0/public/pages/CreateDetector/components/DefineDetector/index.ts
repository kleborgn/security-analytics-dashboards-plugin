/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import DefineDetector from './containers/DefineDetector';

export default DefineDetector;
