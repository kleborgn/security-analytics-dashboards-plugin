/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import AlertConditionPanel from './AlertConditionPanel';

export default AlertConditionPanel;
