/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import ConfigureAlerts from './containers/ConfigureAlerts';

export default ConfigureAlerts;
