/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import Alerts from './containers/Alerts';

export default Alerts;
