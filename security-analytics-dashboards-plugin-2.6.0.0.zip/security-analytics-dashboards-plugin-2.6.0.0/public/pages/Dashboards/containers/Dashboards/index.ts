/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import Dashboards from './Dashboards';

export default Dashboards;
