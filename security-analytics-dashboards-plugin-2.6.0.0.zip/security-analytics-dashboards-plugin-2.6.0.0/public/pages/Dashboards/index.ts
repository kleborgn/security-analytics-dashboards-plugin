/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */

import Dashboards from './containers/Dashboards';

export default Dashboards;
